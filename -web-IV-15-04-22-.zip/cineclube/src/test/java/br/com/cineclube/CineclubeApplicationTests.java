package br.com.cineclube;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CineclubeApplicationTests {

	@Test
	void contextLoads() {
	}

}
