package br.com.cineclube.model;

public enum Category {
	
	acao,
	aventura,
	documentario,
	drama,
	fantasia,
	ficcao_cientifica,
	suspense,
	terror 

}
